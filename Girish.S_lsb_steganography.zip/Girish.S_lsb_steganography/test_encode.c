 /* 
 
NAME              : GIRISH S
DATE              : 29/11/2022
DESCRIPTION       : LSB Image Steganography
SAMPLE INPUT      : 1. For Encoding: ./a.out -e beautiful.bmp secret.txt stego.bmp
                    2. For Decoding: ./a.out -d stego.bmp decode.txt
SAMPLE OUTPUT     : 

1. encoding

<................Selected Encoding................>

<................Read and validation is success..............>

<................Started Encoding.................>


<................Open files is Success................>
<                width = 1024                >
<                height = 768                >

<................Check Capacity is Success................>

<................Copy bmp header is Success................>

<................Magic String is Copied Successfully................>
<                Secret file extention size is 4               >

<................Sectet file data is encoded...............>

<................Secret file extention is encoded................>

<................secret file size is encoded.................>

<................Secret file data is encoded................>

<................Remaining image data is copied................>

<................Encoded done................>

 
 
 2. decoding
 
 <................Selected decoding................>

<................Read and validation of decode is success................>

<................Started Decoding................>


<................open_decode_files is SUCCESS................>

<................magic string is decoded successfully................>

<................secret file extn size is decoded successfully................>

<................secret file extn is not decoded successfully................>

<................secret file size is decoded successfully................>

<................secret file data is decoded successfully................>

<................Decoded done................>

 
 */

#include<stdio.h>
#include<string.h>
#include <stdio.h>
#include "encode.h"
#include "decode.h"
#include "types.h"
#include "common.h"

int main(int argc, char *argv[])
{
	EncodeInfo encInfo;
	uint img_size;
	DecodeInfo decInfo;
	
	// Checking command line is passed or not
	
	if(argc == 1 )											 
	{
	        printf("\n");
		printf("<................Please pass arguments through command line................>\n");
	}
	
	
	if(check_operation_type(argv) == c_encode)							
	{
	       // Enabeling the encoding section
	       
	        printf("\n");
		printf("<................Selected Encoding................>\n");
		printf("\n");
		
		//Checking the read and validation  for ecnoding
		
		if(read_and_validate_encode_args(argv,&encInfo) == e_success)				 
		{
			printf("<................Read and validation is success..............>\n");
			printf("\n");
			
			printf("<................Started Encoding.................>\n");
			printf("\n");
			
			// Start encoding  
			
			if(do_encoding(&encInfo) == e_success)					        																			
			{
			        printf("\n");
				printf("<................Encoded done................>\n");
				printf("\n");
				
			}
			else
			{
			        printf("\n");
				printf("<................Failed to encode.................>\n");
			}
		}
		else
		{
			printf("<................Read and validation is failed................>\n");
		}
	}

	// enabeling the decoding section
	
	else if(check_operation_type(argv) == c_decode)						          
	{
	        printf("\n");
		printf("<................Selected decoding................>\n");
		printf("\n");
		
		// checking the read and validation  for decoding 
		
		if(read_and_validate_decode_arg(argv, &decInfo) == d_success)				  
		{
			printf("<................Read and validation of decode is success................>\n");
			printf("\n");
			printf("<................Started Decoding................>\n");
			printf("\n");
			
			// Start decoding 
			
			if(do_decoding(argv, &decInfo)== d_success)					    
			{
			        printf("\n");
				printf("<................Decoded done................>\n");
				printf("\n");
				
			}
			else
			{
				printf("<................Failed to decode................>\n");
				printf("\n");
			}
		}
		else
		{
			printf("<................Read and validation is failed................>\n");
			printf("\n");
		}
	}
	
	else
    {
	printf("Invalid Option !!\n Usage for encoding\n ./a.out -e beautiful.bmp secret.txt [stego.bmp]\n Usage for decoding\n ./a.out -d  stego.bmp [decoding.txt]\n"); 
    }
	return 0;
}
